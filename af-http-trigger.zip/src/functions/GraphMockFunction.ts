import {
    app,
    HttpRequest,
    HttpResponseInit,
    InvocationContext,
} from '@azure/functions';

// Simulamos que obtenemos un documento Word
import { Packer, Document, Paragraph, TextRun } from 'docx';

// 🚀 Simulamos la obtención del token de Microsoft Graph
async function getMockGraphToken(): Promise<string> {
    // Normalmente acá harías el POST a login.microsoftonline.com con tu clientId/secret
    return 'mocked_graph_token';
}

// 🚀 Simulamos el servicio que trae datos desde una lista SharePoint
async function fetchMockSharePointListItems(token: string) {
    console.log('Usando token:', token);

    // Simulamos los datos como si vinieran desde Graph
    return [
        {
            title: 'Novedad 1',
            area: 'IT',
            fecha: '2025-09-17',
        },
        {
            title: 'Novedad 2',
            area: 'Seguridad',
            fecha: '2025-09-16',
        },
    ];
}

// ✅ Esta es la Azure Function
export async function GraphMockFunction(
    request: HttpRequest,
    context: InvocationContext
): Promise<HttpResponseInit> {
    context.log('📄 Generando Word con datos MOCK de Graph...');

    try {
        // Paso 1: Obtener token (simulado)
        const token = await getMockGraphToken();
        if (!token) {
            context.log('❌ Error al obtener token');
            return { status: 500, body: 'Token de Graph no disponible' };
        }

        // Paso 2: Obtener datos desde SharePoint (simulado)
        const items = await fetchMockSharePointListItems(token);

        // Paso 3: Construir un documento Word con esos datos
        const doc = new Document({
            sections: [
                {
                    properties: {},
                    children: [
                        new Paragraph({
                            children: [
                                new TextRun({
                                    text: 'Reporte de Novedades',
                                    bold: true,
                                    size: 28,
                                }),
                            ],
                        }),
                        ...items.map(
                            (item) =>
                                new Paragraph(
                                    `- ${item.fecha}: [${item.area}] ${item.title}`
                                )
                        ),
                    ],
                },
            ],
        });

        const buffer = await Packer.toBuffer(doc);

        // Paso 4: Enviar como descarga
        return {
            status: 200,
            headers: {
                'Content-Type':
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                'Content-Disposition': 'attachment; filename=Reporte-Mock.docx',
            },
            body: buffer,
        };
    } catch (error: any) {
        context.log('❌ Error general:', error.message || error);
        return {
            status: 500,
            body: `Error inesperado: ${error.message || error}`,
        };
    }
}

// Exportamos la función como HTTP
app.http('GraphMockFunction', {
    methods: ['GET'],
    authLevel: 'anonymous',
    handler: GraphMockFunction,
});
